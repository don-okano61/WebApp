from flask import Flask
from flask_sqlalchemy import SQLAlchemy
from backend.routes import api_bp  # API-Routen importieren

# Flask-Anwendung initialisieren
app = Flask(__name__)
app.config["SQLALCHEMY_DATABASE_URI"] = "postgresql://postgres:yjt65nc5@localhost/bewerbungen_db"

# Datenbank-Objekt erstellen
db = SQLAlchemy(app)

# API-Routen registrieren
app.register_blueprint(api_bp)

# Datenbanktabellen erstellen (mit Anwendungskontext)
with app.app_context():
    db.create_all()

# Server starten
if __name__ == "__main__":
    app.run(debug=True)