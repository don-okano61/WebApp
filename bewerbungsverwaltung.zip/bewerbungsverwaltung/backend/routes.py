from flask import Blueprint, request, jsonify, render_template
from backend import db
from backend.models import Bewerbung

# API-Blueprint erstellen
api_bp = Blueprint("api", __name__)

# ✅ Startseite hinzufügen
@api_bp.route("/", methods=["GET"])
def home():
    return "<h1>Willkommen zur Bewerbungsverwaltung!</h1><p>Diese API verwaltet Bewerbungen.</p>"

# ✅ Bewerbung hinzufügen
@api_bp.route("/bewerbung", methods=["POST"])
def add_bewerbung():
    data = request.json
    bewerbung = Bewerbung(name=data["name"], email=data["email"], status="Offen")
    db.session.add(bewerbung)
    db.session.commit()
    return jsonify({"message": "Bewerbung erfolgreich hinzugefügt"})

# ✅ Alle Bewerbungen abrufen
@api_bp.route("/bewerbungen", methods=["GET"])
def get_bewerbungen():
    bewerbungen = Bewerbung.query.all()
    return jsonify([{"id": b.id, "name": b.name, "email": b.email, "status": b.status} for b in bewerbungen])