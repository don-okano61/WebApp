document.getElementById("bewerbungsForm").addEventListener("submit", async function(e) {
    e.preventDefault();
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;

    await fetch("/bewerbung", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email })
    });

    loadBewerbungen();
});

async function loadBewerbungen() {
    const res = await fetch("/bewerbungen");
    const bewerbungen = await res.json();
    const liste = document.getElementById("bewerbungenListe");
    liste.innerHTML = "";
    bewerbungen.forEach(b => {
        liste.innerHTML += `<li>${b.name} - ${b.email} - Status: ${b.status}</li>`;
    });
}

loadBewerbungen();